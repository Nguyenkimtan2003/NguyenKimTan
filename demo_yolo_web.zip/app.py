from flask import Flask, render_template, request, redirect, url_for
from ultralytics import YOLO
import cv2
import numpy as np
import os
import uuid

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/uploads'

# Load model YOLO
model = YOLO("best.pt")

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        if 'image' not in request.files:
            return redirect(request.url)
        file = request.files['image']
        if file.filename == '':
            return redirect(request.url)
        if file:
            filename = str(uuid.uuid4()) + ".jpg"
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)

            # Nhận diện ảnh
            image = cv2.imread(filepath)
            results = model(image)[0]
            for box in results.boxes:
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                conf = box.conf[0]
                cls = int(box.cls[0])
                label = f"{model.names[cls]}: {conf:.2f}"
                cv2.rectangle(image, (x1, y1), (x2, y2), (0, 255, 0), 2)
                cv2.putText(image, label, (x1, y1 - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
            result_path = os.path.join(app.config['UPLOAD_FOLDER'], "result_" + filename)
            cv2.imwrite(result_path, image)
            return render_template('index.html', uploaded=True,
                                   image_url=url_for('static', filename='uploads/' + "result_" + filename))
    return render_template('index.html', uploaded=False)


if __name__ == '__main__':
    app.run(debug=True)